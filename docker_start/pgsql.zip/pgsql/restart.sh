curPath=$(cd $(dirname $0);pwd)
sh $curPath/stop.sh
sh $curPath/start.sh