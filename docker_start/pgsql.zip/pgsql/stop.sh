docker stop pgsql
docker rm pgsql